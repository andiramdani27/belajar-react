import { Coffee, Leaf, Award, Heart, ShoppingCart, Star } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white">
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <Coffee className="w-8 h-8 text-amber-700" />
              <span className="text-2xl font-bold text-amber-900">BrewMaster</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-700 hover:text-amber-700 transition">Features</a>
              <a href="#products" className="text-gray-700 hover:text-amber-700 transition">Products</a>
              <a href="#testimonials" className="text-gray-700 hover:text-amber-700 transition">Reviews</a>
              <button className="bg-amber-700 text-white px-6 py-2 rounded-full hover:bg-amber-800 transition flex items-center gap-2">
                <ShoppingCart className="w-4 h-4" />
                Shop Now
              </button>
            </div>
          </div>
        </div>
      </nav>

      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold text-amber-900 mb-6 leading-tight">
                Premium Coffee
                <br />
                <span className="text-amber-700">Crafted to Perfection</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Experience the rich, bold flavors of our ethically sourced, small-batch roasted coffee beans. Every cup tells a story of passion and dedication.
              </p>
              <div className="flex flex-wrap gap-4">
                <button className="bg-amber-700 text-white px-8 py-4 rounded-full hover:bg-amber-800 transition text-lg font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                  Order Now
                </button>
                <button className="bg-white text-amber-700 px-8 py-4 rounded-full hover:bg-gray-50 transition text-lg font-semibold border-2 border-amber-700">
                  Learn More
                </button>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-amber-600 to-amber-800 rounded-3xl p-8 shadow-2xl transform rotate-3 hover:rotate-0 transition duration-500">
                <img
                  src="https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Coffee Cup"
                  className="rounded-2xl w-full h-auto shadow-xl"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-amber-900 mb-4">Why Choose BrewMaster?</h2>
            <p className="text-xl text-gray-600">Quality and sustainability in every sip</p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-700 transition">
                <Leaf className="w-8 h-8 text-amber-700 group-hover:text-white transition" />
              </div>
              <h3 className="text-xl font-semibold text-amber-900 mb-2">100% Organic</h3>
              <p className="text-gray-600">Sustainably sourced from ethical farms worldwide</p>
            </div>
            <div className="text-center group">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-700 transition">
                <Award className="w-8 h-8 text-amber-700 group-hover:text-white transition" />
              </div>
              <h3 className="text-xl font-semibold text-amber-900 mb-2">Award Winning</h3>
              <p className="text-gray-600">Recognized globally for exceptional quality</p>
            </div>
            <div className="text-center group">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-700 transition">
                <Coffee className="w-8 h-8 text-amber-700 group-hover:text-white transition" />
              </div>
              <h3 className="text-xl font-semibold text-amber-900 mb-2">Fresh Roasted</h3>
              <p className="text-gray-600">Small-batch roasting for maximum freshness</p>
            </div>
            <div className="text-center group">
              <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-700 transition">
                <Heart className="w-8 h-8 text-amber-700 group-hover:text-white transition" />
              </div>
              <h3 className="text-xl font-semibold text-amber-900 mb-2">Made with Love</h3>
              <p className="text-gray-600">Crafted by passionate coffee artisans</p>
            </div>
          </div>
        </div>
      </section>

      <section id="products" className="py-20 bg-gradient-to-b from-amber-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-amber-900 mb-4">Our Signature Blends</h2>
            <p className="text-xl text-gray-600">Discover your perfect cup</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition group">
              <div className="overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/1695052/pexels-photo-1695052.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Dark Roast"
                  className="w-full h-64 object-cover group-hover:scale-110 transition duration-500"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <h3 className="text-2xl font-bold text-amber-900 mb-2">Dark Roast</h3>
                <p className="text-gray-600 mb-4">Bold and intense with notes of dark chocolate and caramel</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-amber-700">$24.99</span>
                  <button className="bg-amber-700 text-white px-6 py-2 rounded-full hover:bg-amber-800 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition group">
              <div className="overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/1251175/pexels-photo-1251175.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Medium Roast"
                  className="w-full h-64 object-cover group-hover:scale-110 transition duration-500"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <h3 className="text-2xl font-bold text-amber-900 mb-2">Medium Roast</h3>
                <p className="text-gray-600 mb-4">Balanced flavor with hints of nuts and brown sugar</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-amber-700">$22.99</span>
                  <button className="bg-amber-700 text-white px-6 py-2 rounded-full hover:bg-amber-800 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition group">
              <div className="overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/1410224/pexels-photo-1410224.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Light Roast"
                  className="w-full h-64 object-cover group-hover:scale-110 transition duration-500"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <h3 className="text-2xl font-bold text-amber-900 mb-2">Light Roast</h3>
                <p className="text-gray-600 mb-4">Bright and crisp with floral and citrus notes</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-amber-700">$21.99</span>
                  <button className="bg-amber-700 text-white px-6 py-2 rounded-full hover:bg-amber-800 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="testimonials" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-amber-900 mb-4">What Our Customers Say</h2>
            <p className="text-xl text-gray-600">Join thousands of satisfied coffee lovers</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-amber-50 rounded-2xl p-8 shadow-md hover:shadow-xl transition">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-500 text-amber-500" />
                ))}
              </div>
              <p className="text-gray-700 mb-4 leading-relaxed">
                "The best coffee I've ever tasted! The dark roast is absolutely perfect for my morning routine."
              </p>
              <div className="font-semibold text-amber-900">Sarah Mitchell</div>
              <div className="text-sm text-gray-600">Coffee Enthusiast</div>
            </div>
            <div className="bg-amber-50 rounded-2xl p-8 shadow-md hover:shadow-xl transition">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-500 text-amber-500" />
                ))}
              </div>
              <p className="text-gray-700 mb-4 leading-relaxed">
                "Outstanding quality and the customer service is exceptional. I'm a customer for life!"
              </p>
              <div className="font-semibold text-amber-900">Michael Chen</div>
              <div className="text-sm text-gray-600">Business Owner</div>
            </div>
            <div className="bg-amber-50 rounded-2xl p-8 shadow-md hover:shadow-xl transition">
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-500 text-amber-500" />
                ))}
              </div>
              <p className="text-gray-700 mb-4 leading-relaxed">
                "Love that it's organic and sustainably sourced. Tastes amazing and I feel good drinking it!"
              </p>
              <div className="font-semibold text-amber-900">Emma Rodriguez</div>
              <div className="text-sm text-gray-600">Environmental Advocate</div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-r from-amber-700 to-amber-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Transform Your Morning?</h2>
          <p className="text-xl mb-8 opacity-90">Join our community and get 15% off your first order</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <input
              type="email"
              placeholder="Enter your email"
              className="px-6 py-4 rounded-full w-full sm:w-96 text-gray-900 focus:outline-none focus:ring-4 focus:ring-amber-300"
            />
            <button className="bg-white text-amber-700 px-8 py-4 rounded-full hover:bg-gray-100 transition font-semibold whitespace-nowrap shadow-lg">
              Get Started
            </button>
          </div>
        </div>
      </section>

      <footer className="bg-amber-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Coffee className="w-6 h-6" />
                <span className="text-xl font-bold">BrewMaster</span>
              </div>
              <p className="text-amber-200">Premium coffee crafted with passion and dedication.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Products</h4>
              <ul className="space-y-2 text-amber-200">
                <li><a href="#" className="hover:text-white transition">Dark Roast</a></li>
                <li><a href="#" className="hover:text-white transition">Medium Roast</a></li>
                <li><a href="#" className="hover:text-white transition">Light Roast</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-amber-200">
                <li><a href="#" className="hover:text-white transition">About Us</a></li>
                <li><a href="#" className="hover:text-white transition">Our Story</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-amber-200">
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition">Shipping</a></li>
                <li><a href="#" className="hover:text-white transition">Returns</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-amber-800 pt-8 text-center text-amber-200">
            <p>&copy; 2024 BrewMaster. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
